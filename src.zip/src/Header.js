import React from "react";

const Header = (props) => {
  return (
    <header>
      <h1 style={{ margin: "3% 25%" }}>{props.title}</h1>
    </header>
  );
};

export default Header;
